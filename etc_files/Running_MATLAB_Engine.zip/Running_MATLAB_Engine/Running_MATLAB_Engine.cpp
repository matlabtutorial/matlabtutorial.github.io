#define _USE_MATH_DEFINES

#include <iostream>
#include <math.h>
#include <conio.h>
#include <ctype.h>
#include "engine.h"

using namespace std;

int main() {
    Engine* ep = engOpen(NULL);
    double x[1000];

    int i;
    double t = 0;
    const double dt = 0.001;

    mxArray* x_array = mxCreateDoubleMatrix(1000, 1, mxREAL);
    double* px = mxGetDoubles(x_array);

    for (i = 0; i < 1000; i++) {
        x[i] = cos(2 * M_PI * t); // To check numbers in C
        t += dt;

        px[i] = x[i];
    }

    engPutVariable(ep, "x", x_array);
    engEvalString(ep, "plot(x)");
    
    _getch(); // To make cmd stop until pressing any keys.

    engClose(ep);

    return 0;
}
